﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperStore.Domain.Enum
{
    public enum UsuarioStatus
    {

        Desconhecido = 0,
        Ativo,
        Inativo,
        Suspenso
    }
}
