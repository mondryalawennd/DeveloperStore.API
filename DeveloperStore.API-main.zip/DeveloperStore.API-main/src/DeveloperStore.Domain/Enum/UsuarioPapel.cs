﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperStore.Domain.Enum
{
    public enum UsuarioPapel
    {
        Nenhum = 0,
        Cliente,
        Gerente,
        Administrador
      
    }
}
