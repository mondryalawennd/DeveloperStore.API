﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperStore.Application.Vendas.NumeroVenda
{
    public class ObterUltimoNumeroVendaResult
    {
        public string NumeroVenda { get; set; } = string.Empty;
    }
}
