﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperStore.Application.Vendas.DeletarVenda
{
    public class DeletarVendaResponse
    {
        public bool Sucesso { get; set; }
        public string Mensagem { get; set; }=string.Empty;
    }
}
