﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeveloperStore.Application.Cliente.BuscarClientes
{
    public class BuscarClientesResult
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
