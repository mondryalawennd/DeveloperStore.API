﻿namespace DeveloperStore.WebAPI.Features.Cliente.BuscarClientes
{
    public class BuscarClientesResponse
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
