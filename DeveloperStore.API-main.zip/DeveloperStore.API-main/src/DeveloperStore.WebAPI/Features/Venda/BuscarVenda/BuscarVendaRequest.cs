﻿namespace DeveloperStore.WebAPI.Features.Venda.BuscarVenda
{
    public class BuscarVendaRequest
    {
        public int VendaId { get; set; }
    }
}
