﻿namespace DeveloperStore.WebAPI.Features.Venda.NumeroVenda
{
    public class ObterUltimoNumeroVendaResponse
    {
        public string NumeroVenda { get; set; } = string.Empty;
    }
}

