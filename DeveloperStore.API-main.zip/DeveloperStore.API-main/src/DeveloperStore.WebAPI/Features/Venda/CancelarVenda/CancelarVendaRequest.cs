﻿namespace DeveloperStore.WebAPI.Features.Venda.CancelarVenda
{
    public class CancelarVendaRequest
    {
        public int Id { get; set; }
    }
}
