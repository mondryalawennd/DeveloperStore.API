﻿namespace DeveloperStore.WebAPI.Features.Venda.DeletarVenda
{
    public class DeletarVendaRequest
    {
        public int Id { get; set; }
    }
}
