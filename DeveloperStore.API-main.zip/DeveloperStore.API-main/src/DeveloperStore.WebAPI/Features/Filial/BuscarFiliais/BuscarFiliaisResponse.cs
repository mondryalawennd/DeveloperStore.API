﻿namespace DeveloperStore.WebAPI.Features.Filial.BuscarFiliais
{
    public class BuscarFiliaisResponse
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
