interface Cliente {
  id: number;
  nome: string;
}