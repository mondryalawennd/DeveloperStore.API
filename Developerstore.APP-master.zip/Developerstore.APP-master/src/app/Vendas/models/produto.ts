interface Produto {
  id: number;
  nome: string;
  descricao?: string;
  preco: number;
}