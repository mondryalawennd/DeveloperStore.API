import { Component } from '@angular/core';

@Component({
  selector: 'app-editar-venda',
  imports: [],
  templateUrl: './editar-venda.html',
  styleUrl: './editar-venda.scss'
})
export class EditarVenda {

}
